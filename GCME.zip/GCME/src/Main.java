/*
This computational model of emotions (CME) was designed and
implemented by David Rojas-Velazquez.
Email: davidrojasvelazquez@gmail.com

*/


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Main
{
    //This is new--------------------------------
    public static Situation situation;
    //--------------------------------------------
    
    public static void fileWrite(String intensity [][], int numAgents){
        try {
            
            File file = new File("Quake1200.csv");
            FileWriter fw = new FileWriter(file);
            for (int i = 0; i < numAgents; i++)
            {
                for (int j = 0; j < 5; j++){
                    fw.write(intensity[i][j] + " ");
                }//End for j
                fw.write("\n");                    
            }//End for i
            fw.close();
        } catch (Exception ex) {
            System.out.println("The file could not be saved");
        }
        
    }
    
    //This is new------------------------------------------------------
    public static Emotion selectEmotion(int opc, Agent agent)
    {
        Emotion emotionSelected;
        
        emotionSelected = agent.emotions.get(0);
        
        switch (opc){
            case 1:
                Emotion fearEmotion;
                fearEmotion = agent.emotions.get(0);
                emotionSelected = fearEmotion;
                break;
            case 2:
                Emotion anticipationEmotion;
                anticipationEmotion = agent.emotions.get(0);
                emotionSelected = anticipationEmotion;
                break;
            case 3:
                Emotion joyEmotion;
                joyEmotion = agent.emotions.get(0);
                emotionSelected = joyEmotion;
                break;
            case 4:
                Emotion disgustEmotion;
                disgustEmotion = agent.emotions.get(0);
                emotionSelected = disgustEmotion;
                break;
            case 5:
                Emotion angerEmotion;
                angerEmotion = agent.emotions.get(0);
                emotionSelected = angerEmotion;
                break;
        }//End switch (opc)
        
        return emotionSelected;
    }//End selectEmotion
    //----------------------------------------------------------------------
    
    public static void main(String[] args)
    {
        Agent agent;
        Emotion emotionalAgent;
        Scanner opc = new Scanner(System.in);
        int option = 0;
        String intensities[][] = new String [100000][5];
        int tmpIndex = 0;
        int agents;
        Random rnd;
        rnd = new Random ();
        rnd.setSeed(1);
        //
        //Select emotion type
        System.out.println("Select emotion type:");
        System.out.println("1.- Fear");
        System.out.println("2.- Anticipation");
        System.out.println("3.- Joy");
        System.out.println("4.- Disgust");
        System.out.println("5.- Anger");
        option = opc.nextInt();
        
        //*/ determine a situation with numerical values (Global Variables)
        situation = new Situation();
        situation.senseOfRealityDegree = 0.886;
        situation.psychologicalProximityDegree = 0.794;
        situation.unexpectednessDegree = 0.752;
        situation.arousalLevel = 0.822;
        //*
        // assign values to describe situation in terms of 
        //emotion's local variables for joy, fear or anticipation
        //if you are not using these variables, set them zero value
        situation.likelihood = 0.33;
        situation.desirabilityDegree = 0.15;
        // assign values to describe situation in terms of 
        //emotion's local variables for disgust
        //if you are not using these variables, set them zero value
        situation.dislikeDegree = 0.5;
        situation.familiarityDegree = 0.8;
        // assign values to describe situation in terms of 
        //emotion's local variables for anger
        //if you are not using these variables, set them zero value
        situation.censureDegree = 0.3;
        situation.deviationExpectationDegree = 0.7;
        situation.undesirableDegree = 0.2;
        // create and define the agent
        //agent = new Agent();
        agents = 1200;
        intensities[0][0] = "AGENTS"  + ","; 
        intensities[0][1] = "PERCEPTION_COEFFICIENT" + ",";
        intensities[0][2] = "EMOTION" + ",";
        intensities[0][3] = "INTENSITY" + ",";
        intensities[0][4] = "BEHAVIOR" + ",";
        agents = agents + 1;
        for (int i = 0; i < agents; i++){
            agent = new Agent();
            tmpIndex = i + 1;
            
            agent.setSenseOfRealityDegreeWeight(rnd.nextDouble());
            agent.setPsychologicalProximityDegreeWeight(rnd.nextDouble());
            agent.setUnexpectednessDegreeWeight(rnd.nextDouble());
            agent.setArousalLevelWeight(rnd.nextDouble());
            
            //Uncomment the following section for single agent analysis
            /*agent.setSenseOfRealityDegreeWeight(0.5);
            agent.setPsychologicalProximityDegreeWeight(0.8);
            agent.setUnexpectednessDegreeWeight(0.3);
            agent.setArousalLevelWeight(0.8);*/
                        
            // the agent will have emotions
            agent.generateEmotions(situation, option);
            
            emotionalAgent = selectEmotion(option, agent);
            
            agent.setToken(emotionalAgent.getIntensity());
            agent.setReaction(emotionalAgent.getIntensity());
            intensities[tmpIndex][0] = "Agent_" + String.valueOf(tmpIndex) + ","; 
            intensities[tmpIndex][1] = String.valueOf(emotionalAgent.getPerseption()) + ",";
            intensities[tmpIndex][2] = String.valueOf(agent.getToken()) + ",";
            intensities[tmpIndex][3] = String.valueOf(emotionalAgent.getIntensity()) + ",";
            intensities[tmpIndex][4] = String.valueOf(agent.getReaction());
            
        }//end for i
        fileWrite(intensities, agents);
        System.out.println("Simulation finished");
    }//end main
}//end Main
