public class FearEmotion extends ConsequencesOfSituation
{

    public FearEmotion(Situation situation)
    {
        super(situation);
        /*pleased = false;
        displeased = true;*/
    }//end constructor

    public void determineIntensity()
    {
        intensity = ( desirabilityDegree + likelihood ) * perceptionIntensityCoefficient;
        // normalization...
        if (intensity > 1){
            intensity = (1 / (1 + Math.exp(-intensity) ));
        }// end if (intensity > 1)
    }//end determineIntensity
   
    public boolean crossedTheThreshold()
    {
        return true;
        // por ahora
    }//end crossedTheThreshold
    
    //Tokens associated with fear
    public void determineToken(double intensity)
    {
        
        int sel = 0;
        
        if (intensity < 0.55){
            sel = (int)(Math.random() * 6+ 1);
            switch (sel){
                case 1:
                    token = "Scared";
                    break;
                case 2:
                    token = "Apprehensive";
                    break;
                case 3:
                    token = "Nervous";
                    break;
                case 4:
                    token = "Anxious";
                    break;
                case 5:
                    token = "Timid";
                    break;
                case 6:
                    token = "Worried";
                    break;
            }//End switch (sel)
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 3+ 1);
            switch (sel){
                case 1:
                    token = "Fear";
                    break;
                case 2:
                    token = "Cowering";
                    break;
                case 3:
                    token = "Frighten";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 3) + 1;
            switch (sel){
                case 1:
                    token = "Terrified";
                    break;
                case 2:
                    token = "Fright";
                    break;
                case 3:
                    token = "Dread";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.8)
    }//End determineToken
    
    //Behavior tokens associated with fear tokens
    public void determineReaction(double intensity)
    {
        int sel = 0;
        //Adding behavior of the agent using Plutchik's tokens proposed
        
        //Low - Medium intensity
        if (intensity < 0.55){
            reaction = "Walk_away_from_danger";
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 3+ 1);
            switch (sel){
                case 1:
                    reaction = "Escape";
                    break;
                case 2:
                    reaction = "Flight";
                    break;
                case 3:
                    reaction = "Fight";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 2) + 1;
            switch (sel){
                case 1:
                    reaction = "Freezing";
                    break;
                case 2:
                    reaction = "Petrified";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.75)
    }//end determineReaction

}//end FearEmotion


