// Emoción
public abstract class Emotion
{

    // intensity of the emotion
    // between 0 and 1
    double intensity;


    // Global Variables affecting intensity
    // Their values will be the same for all agents.
    // and will be determined according to the situation
    // when we define the simulation parameters

    // Each agent will have its own weights, randomly generated,
    // when the agent is created
    // The weights represent the personality of the agent
    // each value will be between 0 an 1
    // (the sum does not need to be 1.0

    // sense of reality degree -
    // How much the situation is real
    double senseOfRealityDegree;

    // psychologycal proximity (space or time)
    // how close is the psychological space/time of the situation
    double psychologicalProximityDegree;

    // unexpectedness
    // how much the situation is surprising
    double unexpectednessDegree;

    // arousal
    // how much the environment is aroused prior to the situation
    double arousalLevel;
    //Token
    String token;
    String reaction;

    double perceptionIntensityCoefficient;
    
    //Definition of local variables for joy, fear and anticipation
    double desirabilityDegree;
    double likelihood;
    
    //Definition of local variables for disgust
    double dislikeDegree;
    double familiarityDegree;

    //local variables for anger
    double censureDegree;
    double deviationExpectationDegree;
    double undesirableDegree;
    

    // METHODS ////////////////////////////////////////////////////////////////


    public abstract void determineIntensity();

    public abstract boolean crossedTheThreshold();
    
    public abstract void determineToken(double intensity);
    
    public abstract void determineReaction(double intensity);
    

    ////////////////////////////////////////////////////////////////////////////

    public void determinePerceptionIntensityCoefficient(Agent agent)
    {
        perceptionIntensityCoefficient =
        senseOfRealityDegree * agent.senseOfRealityDegreeWeight+
        psychologicalProximityDegree * agent.psychologicalProximityDegreeWeight+
        unexpectednessDegree  * agent.unexpectednessDegreeWeight+
        arousalLevel * agent.arousalLevelWeight;
        
    }//end definePerceptionIntensityCoefficient

     public double getPerseption(){
        return perceptionIntensityCoefficient;
    }
    
    public double getIntensity()
    {
        return intensity;
    }//end getIntensity

    public String getToken(){
        return token;
    }//End getToken
    
    public String getReaction(){
        return reaction;
    }//End getToken
    
     public void setLikelihoodDegree(double degree)
    {
        likelihood = degree;
    }//end set
     
    public void setDesirabilityDegree(double degree)
    {
        // based on the relation between the event and the goals
        // if the event supports goals
        // or if the event difficults goals
        //We can supose that lower value means the event is undesirable
        desirabilityDegree = degree;
    }//end determineDesirabilityDegree
    
    public void setDislikeDegree(double degree)
    {
        dislikeDegree = degree;
    }//end setDislikeDegree
    
    public void setFamiliarityDegree(double degree)
    {
        familiarityDegree = degree;
    }//end setFamiliarityDegree
    
    public void setCensureDegree(double degree)
    {
        censureDegree = degree;
    }//end setcensureDegree
    
    public void setDeviationExpectationDegree(double degree)
    {
        deviationExpectationDegree = degree;
    }//end setcensureDegree
    
    public void setUndesirableDegree(double degree)
    {
        undesirableDegree = degree;
    }//end setcensureDegree
    
}//end Emotion

