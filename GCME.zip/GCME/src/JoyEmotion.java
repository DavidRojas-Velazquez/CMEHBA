//Joy emotion group
public class JoyEmotion extends ConsequencesOfSituation{
    


    public JoyEmotion(Situation situation)
    {
        super(situation);
        /*pleased = true;
        displeased = false;*/
    }//end constructor


    public void determineIntensity()
    {
        intensity = desirabilityDegree * perceptionIntensityCoefficient;
        // normalization...
        if (intensity > 1){
            intensity = (1 / (1 + Math.exp(-intensity) ));
        }//End if (intensity > 1)
    }//end determineIntensity


    public boolean crossedTheThreshold()
    {
        return true;
        // por ahora
    }//end crossedTheThreshold
    
    public void determineToken(double intensity){
        
        int sel = 0;
        
        if (intensity < 0.55){
            sel = (int)(Math.random() * 2+ 1);
            switch(sel){
                case 1:
                    token = "Serenity";
                    break;
                case 2:
                    token = "Glad";
                    break;
            }//En switch(sel)
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 3+ 1);
            switch (sel){
                case 1:
                    token = "Joy";
                    break;
                case 2:
                    token = "Happiness";
                    break;
                case 3:
                    token = "Enthusiasm";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 4) + 1;
            switch (sel){
                case 1:
                    token = "Ecstasy";
                    break;
                case 2:
                    token = "Enjoyment";
                    break;
                case 3:
                    token = "Jubilance";
                    break;
                case 4:
                    token = "Euphoria";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.8)
    }//End determineToken
    
    public void determineReaction(double intensity){
        
         int sel = 0;
        //Adding behavior of the agent using Plutchik's tokens proposed
        
        //Low - Medium intensity
        if (intensity < 0.55){
            sel = (int)(Math.random() * 2+ 1);
            switch (sel){
                case 1:
                    reaction = "Positive Attitude";
                    break;
                case 2:
                    reaction = "Be Optimistic";
                    break;
            }//End switch (sel)
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 2+ 1);
            switch (sel){
                case 1:
                    reaction = "Laugh";
                    break;
                case 2:
                    reaction = "Smile";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 3) + 1;
            switch (sel){
                case 1:
                    reaction = "Jump with Joy";
                    break;
                case 2:
                    reaction = "Celebrate";
                    break;
                case 3:
                    reaction = "Cry for Joy";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.8)
    }//End determineReaction

}
