public class DisgustEmotion extends ConsequencesOfSituation
{

    public DisgustEmotion(Situation situation)
    {
        super(situation);
        /*pleased = false;
        displeased = true;*/
    }//end constructor

    public void determineIntensity()
    {
        intensity = (dislikeDegree + familiarityDegree) * perceptionIntensityCoefficient;
        // normalization...
        if (intensity > 1){
            intensity = (1 / (1 + Math.exp(-intensity) ));
        }// end if (intensity > 1)
    }//end determineIntensity
   
    public boolean crossedTheThreshold()
    {
        return true;
        // por ahora
    }//end crossedTheThreshold
    
    //Tokens associated with fear
    public void determineToken(double intensity)
    {
        
        int sel = 0;
        
        if (intensity < 0.55){
            sel = (int)(Math.random() * 2+ 1);
            switch (sel){
                case 1:
                    token = "Dislike";
                    break;
                case 2:
                    token = "Disgust";
                    break;
                
            }//End switch (sel)
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 2+ 1);
            switch (sel){
                case 1:
                    token = "Aversion";
                    break;
                case 2:
                    token = "Repulsion";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 4) + 1;
            switch (sel){
                case 1:
                    token = "Abhor";
                    break;
                case 2:
                    token = "Detest";
                    break;
                case 3:
                    token = "Hate";
                    break;
                case 4:
                    token = "Repugnance";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.8)
    }//End determineToken
    
    //Behavior tokens associated with fear tokens
    public void determineReaction(double intensity)
    {
        int sel = 0;
        //Adding behavior of the agent using Plutchik's tokens proposed
        
        //Low - Medium intensity
        if (intensity < 0.55){
             sel = (int) (Math.random() * 3) + 1;
            switch (sel){
                case 1:
                    reaction = "Reject";
                    break;
                case 2:
                    reaction = "Repel";
                    break;
                case 3:
                    reaction = "Step aside";
                    break;
            }//End switch (sel)
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 4+ 1);
            switch (sel){
                case 1:
                    reaction = "Walk away";
                    break;
                case 2:
                    reaction = "Censure";
                    break;
                case 3:
                    reaction = "Get annoyed";
                    break;
                case 4:
                    reaction = "Discard";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 3) + 1;
            switch (sel){
                case 1:
                    reaction = "Yell";
                    break;
                case 2:
                    reaction = "Eliminate";
                    break;
                case 3:
                    reaction = "Do away with";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.8)
    }//end determineReaction

}//end DisgustEmotion
