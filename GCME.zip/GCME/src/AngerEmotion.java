public class AngerEmotion extends ConsequencesOfSituation
{

    public AngerEmotion(Situation situation)
    {
        super(situation);
        /*pleased = false;
        displeased = true;*/
    }//end constructor

    public void determineIntensity()
    {
        intensity = (censureDegree + deviationExpectationDegree + undesirableDegree) * perceptionIntensityCoefficient;
        // normalization...
        if (intensity > 1){
            intensity = (1 / (1 + Math.exp(-intensity) ));
        }// end if (intensity > 1)
    }//end determineIntensity
   
    public boolean crossedTheThreshold()
    {
        return true;
        // por ahora
    }//end crossedTheThreshold
    
    //Tokens associated with fear
    public void determineToken(double intensity)
    {
        
        int sel = 0;
        
        if (intensity < 0.55){
            sel = (int)(Math.random() * 3+ 1);
            switch (sel){
                case 1:
                    token = "Exasperate";
                    break;
                case 2:
                    token = "Annoyance";
                    break;
                case 3:
                    token = "Indignation";
                    break;
                
            }//End switch (sel)
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 3+ 1);
            switch (sel){
                case 1:
                    token = "Anger";
                    break;
                case 2:
                    token = "Fury";
                    break;
                case 3:
                    token = "Irritation";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 2) + 1;
            switch (sel){
                case 1:
                    token = "Wrath";
                    break;
                case 2:
                    token = "Rage";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.8)
    }//End determineToken
    
    //Behavior tokens associated with fear tokens
    public void determineReaction(double intensity)
    {
        int sel = 0;
        //Adding behavior of the agent using Plutchik's tokens proposed
        
        //Low - Medium intensity
        if (intensity < 0.55){
            reaction = "Frown and clenched lips";
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 4+ 1);
            switch (sel){
                case 1:
                    reaction = "Speak loud";
                    break;
                case 2:
                    reaction = "Yell";
                    break;
                case 3:
                    reaction = "Violent gestures";
                    break;
                case 4:
                    reaction = "Insult";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 3) + 1;
            switch (sel){
                case 1:
                    reaction = "Hit";
                    break;
                case 2:
                    reaction = "Attack";
                    break;
                case 3:
                    reaction = "Get violent";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.8)
    }//end determineReaction

}//end AngerEmotion

