//Variables that define the situation
public class Situation {
    // sense of reality degree -
        // degree of awareness about the event
        double senseOfRealityDegree;

        // psychologycal proximity (space or time)
        // degree of proximity of the event
        double psychologicalProximityDegree;

        // unexpectedness
        // degree of unexpectedness about the event
        double unexpectednessDegree;

        // arousal
        // level of excitation
        double arousalLevel;
        
        //local variables for joy, fear and anticipation
        double desirabilityDegree;
        double likelihood;
        
        //local variables for disgust
        double dislikeDegree;
        double familiarityDegree;
        
        //local variables for disgust
        double censureDegree;
        double deviationExpectationDegree;
        double undesirableDegree;
}//End situation
