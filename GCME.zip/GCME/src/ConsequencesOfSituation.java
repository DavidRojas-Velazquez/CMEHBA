
public abstract class ConsequencesOfSituation extends Emotion{
    
    public ConsequencesOfSituation (Situation situation){
        senseOfRealityDegree = situation.senseOfRealityDegree;
        psychologicalProximityDegree = situation.psychologicalProximityDegree;
        unexpectednessDegree = situation.unexpectednessDegree;
        arousalLevel = situation.arousalLevel;
    }
}
