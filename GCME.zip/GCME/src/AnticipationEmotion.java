//In OCC this emotion group is called Hope emotions
public class AnticipationEmotion extends ConsequencesOfSituation
{


    public AnticipationEmotion(Situation situation)
    {
        super(situation);
        /*pleased = true;
        displeased = false;*/
    }//end constructor


    public void determineIntensity()
    {
        intensity = ( desirabilityDegree + likelihood ) * perceptionIntensityCoefficient;
        // normalization...
        if (intensity > 1){
            intensity = (1 / (1 + Math.exp(-intensity) ));
        }// end if (intensity > 1)
    }//end determineIntensity


    public boolean crossedTheThreshold()
    {
        return true;
        // por ahora
    }//end crossedTheThreshold
    
    public void determineToken(double intensity){
        
        int sel = 0;
        
        if (intensity < 0.55){
            token = "Interest";
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 2+ 1);
            switch (sel){
                case 1:
                    token = "Anticipation";
                    break;
                case 2:
                    token = "Hope";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 2) + 1;
            switch (sel){
                case 1:
                    token = "Expectancy";
                    break;
                case 2:
                    token = "Excitement";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.8)
    }//End determineToken
    
    public void determineReaction(double intensity){
        
         int sel = 0;
        //Adding behavior of the agent using Plutchik's tokens proposed
        
        //Low - Medium intensity
        if (intensity < 0.55){
            sel = (int)(Math.random() * 3+ 1);
            switch (sel){
                case 1:
                    reaction = "Examination";
                    break;
                case 2:
                    reaction = "Interrogate";
                    break;
                case 3:
                    reaction = "Ask";
                    break;
            }//End switch (sel)
        }//End if (intensity < 0.6) 
        
        //Medium - High intensity
        if (intensity >= 0.55 && intensity < 0.8){
            sel = (int)(Math.random() * 5+ 1);
            switch (sel){
                case 1:
                    reaction = "Believe";
                    break;
                case 2:
                    reaction = "Aspire";
                    break;
                case 3:
                    reaction = "Prevision";
                    break;
                case 4:
                    reaction = "Prediction";
                    break;
                case 5:
                    reaction = "Planning";
                    break;
            }//End switch (sel)
        }//End if (intensity == 0.6 && intensity < 0.8)
        
        //Extremely High intensity
        if(intensity >= 0.8){
            sel = (int) (Math.random() * 4) + 1;
            switch (sel){
                case 1:
                    reaction = "Anxious";
                    break;
                case 2:
                    reaction = "Eager";
                    break;
                case 3:
                    reaction = "Wishful";
                    break;
                case 4:
                    reaction = "Impatient";
                    break;
            }//End switch (sel)
        }//End if(intensity >= 0.8)
    }//End determineReaction

}//end FearEmotion
