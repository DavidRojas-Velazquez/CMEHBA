import java.util.Vector;
import java.util.Random;

// Entity that emulates emotions
public class Agent
{
    Vector<Emotion> emotions;
    String reaction;
    Emotion emotion;
    String token;
    double senseOfRealityDegreeWeight;
    double psychologicalProximityDegreeWeight;
    double unexpectednessDegreeWeight;
    double arousalLevelWeight;
    //
    
    public Agent()
    {
        emotions = new Vector<Emotion>();
    }//end constructor
    
    public void setToken(double intensity){
           emotion.determineToken(intensity);
        
    }//End setToken
    
    public String getToken(){
            token = emotion.getToken();
        return token;
    }//End getToken

    public void setReaction(double intensity){
            emotion.determineReaction(intensity);
    }//End setReaction
    
    public String getReaction(){
            reaction = emotion.getReaction();
        return reaction;
    }//End getReaction

    public void setSenseOfRealityDegreeWeight(double weigth)
    {
        senseOfRealityDegreeWeight = weigth;
    }//end setSenseOfRealityDegree


    public void setPsychologicalProximityDegreeWeight(double weigth)
    {
        psychologicalProximityDegreeWeight = weigth;
    }//end setPsychologicalProximityDegree


    public void setUnexpectednessDegreeWeight(double weigth)
    {
        unexpectednessDegreeWeight = weigth;
    }//end setUnexpectednessDegree


    public void setArousalLevelWeight(double weigth)
    {
        arousalLevelWeight = weigth;
    }//end setArousalLevel


    public void generateEmotions(Situation situation, int opc)
    {
        // the agent may have fear (we create just one emotion for the agent)
        switch (opc){
            case 1: 
                emotion = new FearEmotion(situation);
                break;
            case 2: 
                emotion = new AnticipationEmotion(situation);
                break;
            case 3:
                emotion = new JoyEmotion(situation);
                break;
            case 4:
                emotion = new DisgustEmotion(situation);
                break;
            case 5:
                emotion = new AngerEmotion(situation);
                break;
        }// End switch(opc)
            // definition of the agent's Perception Intensity Coefficient
            emotion.determinePerceptionIntensityCoefficient(this);
            // definition of local variables
            emotion.setLikelihoodDegree(situation.likelihood);
            emotion.setDesirabilityDegree(situation.desirabilityDegree);
            emotion.setDislikeDegree(situation.dislikeDegree);
            emotion.setFamiliarityDegree(situation.familiarityDegree);
            emotion.setCensureDegree(situation.censureDegree);
            emotion.setDeviationExpectationDegree(situation.deviationExpectationDegree);
            emotion.setUndesirableDegree(situation.undesirableDegree);
            
            //emotion.determineUndesirabilityDegree(0.5);
            // determine the intensity of the emotion
            emotion.determineIntensity();
            // add the emotion to the set of emotions the agent may have
            emotions.add(emotion);

    }//end generateEmotions


}//end Agent

